# DKS Academy Website

A React-based frontend for Deutsche Karriere Schule Academy.

## Features

- Course landing page
- Smooth scroll navigation
- Enrollment form with Supabase integration
- Admin dashboard to view enrollments
- Animated UI with Framer Motion

## Setup Instructions

1. Clone the repo
2. Install dependencies with `npm install`
3. Create a `.env` file from `.env.example` and fill in your Supabase keys
4. Run locally with `npm run dev`

## Tech Stack

- React + Tailwind
- Framer Motion
- Supabase
